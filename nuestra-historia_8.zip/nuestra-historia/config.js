/* ✏️ EDITA SOLO ESTE ARCHIVO. Las fotos van en la carpeta "fotos". */
const CONFIG = {
  ella: "Mi vida",
  yo: "Tu nombre",
  desde: "2026-08-23",              // AAAA-MM-DD
  titulo: "Nuestra historia",
  mensaje: "Hice esto para ti, para guardar los momentos que más quiero. Eres mi lugar favorito en el mundo y te amo muchísimo.",
  musica: "musica.mp3",                        // opcional: "cancion.mp3" (en esta misma carpeta)
  clave: "",                         // opcional: palabra secreta para entrar (ej: "frutilla")
  /* fotos: ["archivo.jpg", "frase opcional", "Álbum opcional"] → deja las comillas vacías si no quieres frase */
  fotos: [
    ["foto1.jpg","",""],
    ["foto2.jpg","",""],
    ["foto3.jpg","",""],
    ["foto4.jpg","",""],
    ["foto5.jpg","",""],
    ["foto6.jpg","",""],
    ["foto7.jpg","",""],
    ["foto8.jpg","",""],
    ["foto9.jpg","",""],
    ["foto10.jpg","",""],
    ["foto11.jpg","",""],
    ["foto12.jpg","",""],
    ["foto13.jpg","",""],
    ["foto14.jpg","",""],
    ["foto15.jpg","",""],
    ["foto16.jpg","",""],
    ["foto17.jpg","",""],
    ["foto18.jpg","",""]
  ],
  hitos: [
    { fecha: "21 de abril", titulo: "Primera vez que le escribí a la Coni", texto: "A mí me estaba empezando a interesar la Coni y estaba un poco nervioso." },
    { fecha: "Nuestra primera cita", titulo: "Los nervios", texto: "Yo estaba más nervioso porque ya me gustabas. Ese día lo pasé súper bien y entendí que me encantabas." },
    { fecha: "Nuestro primer beso", titulo: "Ese momento", texto: "Solo diré: gallito inglés 😂" },
    { fecha: "23 de agosto de 2026", titulo: "Cuando te pedí pololeo", texto: "El mejor día de todos, porque empezamos nuestra relación oficial." },
    { fecha: "Hoy", titulo: "Y sigo eligiéndote", texto: "Cada día un poquito más. Te amo." }
  ],
  /* cartas: una por línea → Título|Texto */
  cartas: `
Cuando estés triste|Aunque todo pueda estar mal, mi amor, yo nunca te dejaré sola.
Cuando me extrañes|Cierra los ojitos preciosos que tienes, mi amor, e imagina que te estoy abrazando. Aunque no esté ahí, mi corazoncito siempre está donde estás tú, mi amor.
Cuando no puedas dormir|Te estoy mandando un abrazito gigante desde mis sueños, mi amor. Descansa, mi amor, para que podamos abrazarnos en nuestros sueños, amor.
Cuando dudes de ti|Eres inteligente, deportista, fuerte, buena para el tenis y hermosa. Ojalá pudieras verte desde mis ojos, porque te enamorarías de ti como yo, amor.
Cuando estés enojada conmigo|Perdóname si te hice sentir mal, amor. Te amo, y quiero arreglar siempre las cosas contigo, con calma y con cariño.
Cuando necesites un abrazo|Imagina el abrazo más largo y más fuerte que puedas, ese te lo estoy dando ahora mismo, mi amorrr.
Cuando quieras escuchar que te amo|Te amo. Hoy, mañana y todos los días que vengan. Nunca lo dudes.`,
  /* carta final: queda abajo y se abre con contraseña */
  cartaFinal: {
    titulo: "Cuando leas la última carta 🔒",
    clave: "te amo",
    pista: "Pista: lo que más te digo 💗",
    texto: "Eres lo mejor que me ha pasado en mi vida, mi niña. Quiero construir un futuro juntos y estar juntos para siempre, mi amor. Te amo muchísimooooo."
  },
  razones: `
Porque me haces reír hasta cuando estoy de mal humor
Porque eres linda por fuera y más linda por dentro
Porque contigo me siento en casa
Porque te preocupas por mí sin que te lo pida
Por tu sonrisa, que me desarma entero
Porque contigo hasta lo más simple es especial
Porque eres mi persona favorita
Por cómo me miras
Por tu risa, que me encanta
Porque me abrazas y se me olvida todo
Porque me entiendes sin que hable
Por lo linda que te ves recién despertada
Porque eres mi mejor amiga
Porque contigo puedo ser yo mismo
Por cómo hablas cuando estás emocionada
Porque me tienes paciencia cuando soy difícil
Por tus ojos
Por tus manos chiquititas
Porque me haces querer ser mejor persona
Por lo que cantas cuando crees que nadie te escucha
Porque eres muy inteligente
Por cómo te ríes de tus propios chistes
Porque eres muy valiente
Porque me haces sentir importante
Por tus abrazos que son lo mejor del mundo
Por tus besos
Porque con una sola mirada ya me alegras el día
Porque eres muy leal
Por cómo cuidas a la gente que quieres
Por tu manera de pensar
Porque siempre me escuchas
Por las conversaciones de madrugada que me hacen reír
Porque me apoyas en todo
Porque eres tan tierna
Por tu voz
Por cómo me dices mi amor
Porque creíste en mí
Porque eres única
Por tu olor, que me encanta
Porque me haces sentir tranquilo
Porque contigo el tiempo pasa volando
Por tus ganas de vivir
Por cómo te enojas, que igual te ves linda
Porque me das paz
Por tus mensajes de buenos días
Por cómo me tomas la mano
Porque eres mi lugar seguro
Porque me haces feliz sin esforzarte
Por tu sentido del humor
Porque eres la polola más linda del mundo
Por tus abrazos por la espalda
Porque contigo todo tiene sentido
Por lo mucho que me cuidas cuando ando enfermo
Porque no te rindes
Por cómo bailas aunque lo hagas mal
Por tus ocurrencias
Porque me dejas ser débil
Porque me haces sentir querido
Por tus caritas cuando algo no te gusta
Por tu sonrisa de recién levantada
Porque eres muy buena persona
Por cómo te ilusionas con las cosas chicas
Por tu corazón gigante
Porque me haces mejor
Por cómo me defiendes
Por tu forma de ser
Porque contigo no me aburro nunca
Por tus ganas de que estemos bien
Por cómo me miras cuando crees que no me doy cuenta
Por tu paciencia conmigo
Porque me haces sentir afortunado
Por tus pecas, tus lunares y todo lo tuyo
Porque contigo me dan ganas de futuro
Por tu manera de querer
Porque eres mi mejor decisión
Por tus audios largos que escucho mil veces
Por cómo te preocupas por todos
Porque eres sincera conmigo
Por cómo me haces sentir cuando llegas
Porque amo cómo eres
Por tus locuras
Porque contigo las cosas malas pesan menos
Por tus abrazos largos
Por tu forma de decir mi nombre
Porque siento que me eliges igual que yo a ti
Por cómo me haces sentir cuando me dices que me amas
Porque me encantan tus defectos también
Por tus ganas de hacer cosas conmigo
Porque eres mi mundo
Por tus detalles
Por tu cariño
Porque me hiciste creer en el amor
Porque contigo todo es más bonito
Porque eres mi todo
Por cómo me haces reír con tus ocurrencias
Porque contigo siento que todo va a salir bien
Por tus ganas de lograr todo lo que te propones
Por cómo me haces sentir en las buenas y en las malas
Porque eres mi lugar favorito
Y porque simplemente te amo, sin necesidad de una razón`,
  planes: `
Casarnos
Elegir juntos el lugar donde nos casaremos
Decirnos "sí, acepto" frente a todos los que amamos
Escribir nuestros propios votos
Bailar nuestro primer baile como esposos
Usar anillos que nos recuerden siempre nuestro amor
Vivir juntos
Despertar juntos todos los días
Tener nuestra propia casa
Elegir juntos cada rincón de nuestro hogar
Decorar nuestra casa con nuestras fotos
Tener un perrito
Tener un gatito también
Cuidar juntos a nuestras mascotas
Tener hijos o hijas
Elegir juntos sus nombres
Conocer a nuestro primer bebé
Ver a nuestros hijos dar sus primeros pasos
Escuchar sus primeras palabras
Arroparlos cada noche
Contarles cómo nos conocimos
Llevarlos a su primer día de colegio
Enseñarles a andar en bicicleta
Enseñarles a ser buenas personas
Ser su mayor apoyo
Verlos crecer felices
Verlos graduarse
Ver cómo forman su propia familia
Ser abuelos juntos
Tener una gran familia
Crear nuestras propias tradiciones familiares
Celebrar juntos cada Navidad
Celebrar juntos cada Año Nuevo
Celebrar cada uno de nuestros cumpleaños
Celebrar cada aniversario
Renovar nuestros votos
Terminar nuestros estudios
Apoyarnos en nuestras carreras
Ir a la graduación del otro
Cumplir nuestros sueños profesionales
Trabajar juntos por nuestro futuro
Ahorrar juntos para nuestra casa
Tener estabilidad y tranquilidad
Construir nuestro hogar paso a paso
Viajar juntos
Conocer lugares nuevos juntos
Viajar por el mundo tomados de la mano
Tener un lugar especial que sea solo nuestro
Volver a los lugares donde fuimos felices
Cumplir juntos nuestros sueños de infancia
Tener nuestra propia rutina de las mañanas
Prepararnos el desayuno el uno al otro
Cocinar juntos nuestra cena favorita
Tener una comida que sea la favorita de nuestra casa
Regalarnos pequeños detalles todos los días
Escribirnos cartas de amor toda la vida
Guardar todos nuestros recuerdos en una caja
Armar un álbum con todas nuestras fotos
Hacer una cápsula del tiempo para abrirla en el futuro
Tener nuestro propio idioma de cariño
Tener nuestras canciones favoritas
Bailar en la cocina
Reírnos juntos todos los días
Dormir abrazados cada noche
Decirnos "te amo" todos los días
Nunca irnos a dormir enojados
Resolver todo con amor y paciencia
Cuidarnos cuando estemos enfermos
Escucharnos siempre
Apoyarnos en los días difíciles
Superar juntos todos los obstáculos
Ser el mejor amigo del otro
Crecer juntos como personas
Aprender cosas nuevas juntos
Cumplir cada meta que nos propongamos
Ayudar juntos a quienes lo necesiten
Plantar un árbol que crezca junto a nuestra familia
Tener un jardín lleno de flores
Pasar tardes tranquilas juntos
Ver el atardecer juntos
Mirar las estrellas abrazados
Tomarnos de la mano en cualquier lugar
Caminar juntos sin prisa
Tener nuestras costumbres de domingo
Ver juntos nuestras películas favoritas
Tener una vida tranquila y feliz
Ser el hogar del otro
Ser el refugio del otro
No dejar nunca de enamorarnos
Seguir eligiéndonos todos los días
Celebrar nuestras bodas de plata
Celebrar nuestras bodas de oro
Envejecer juntos
Sentarnos a recordar toda nuestra historia
Mirar atrás y sentirnos orgullosos de lo que construimos
Tomarnos de la mano hasta ser viejitos
Dejar un hermoso legado a nuestra familia
Seguir queriéndonos como el primer día
Ser felices, siempre juntos
Y amarnos hasta el último día`,
  pregunta: "¿Quieres seguir siendo mi persona favorita?",
  final: "Sabía que dirías que sí 💖 Te amo muchísimo, gracias por todo."
};
