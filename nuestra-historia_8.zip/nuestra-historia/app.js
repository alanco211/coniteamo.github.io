const $=s=>document.querySelector(s),C=CONFIG;
const heart="data:image/svg+xml;utf8,"+encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'><rect width='600' height='600' fill='#FFD6E0'/><text x='300' y='360' font-size='220' text-anchor='middle'>💗</text></svg>");
const guarda=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
const lee=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))||d}catch(e){return d}};
C.fotos=C.fotos.map(f=>Array.isArray(f)?{archivo:f[0],texto:f[1],album:f[2]}:f);
['razones','planes'].forEach(k=>{if(typeof C[k]==='string')C[k]=C[k].trim().split('\n').map(x=>x.trim()).filter(Boolean)});
if(typeof C.cartas==='string')C.cartas=C.cartas.trim().split('\n').map(l=>{const[t,...x]=l.split('|');return{titulo:t.trim(),texto:x.join('|').trim()}});
$('#saludo').textContent=`Hola, ${C.ella} 💗`;$('#titulo').textContent=C.titulo;
$('#firma').textContent=`Te amo con todo mi corazón, ${C.yo} ♥`;document.title=C.titulo;
if(C.clave){$('#clave').hidden=false;$('#pista').textContent="Escribe la palabra secreta y toca";}

/* corazones y explosiones */
function corazon(){const s=document.createElement('span');s.textContent=['💗','💕','💖','🌸','✨'][Math.random()*5|0];
 s.style.left=Math.random()*100+'vw';s.style.fontSize=14+Math.random()*22+'px';s.style.animationDuration=7+Math.random()*6+'s';
 $('#corazones').appendChild(s);setTimeout(()=>s.remove(),14000)}
setInterval(corazon,900);
function burst(x,y,n=14){for(let i=0;i<n;i++){const p=document.createElement('span');p.className='pop';p.textContent=['💗','💖','💕','🌸'][i%4];
 p.style.left=x+'px';p.style.top=y+'px';document.body.appendChild(p);const a=Math.random()*6.28,d=60+Math.random()*110;
 p.animate([{transform:'translate(0,0) scale(.5)',opacity:1},{transform:`translate(${Math.cos(a)*d}px,${Math.sin(a)*d-60}px) scale(1.3)`,opacity:0}],{duration:1100,easing:'ease-out'}).onfinish=()=>p.remove()}}
const centro=()=>burst(innerWidth/2,innerHeight/2,40);

/* contador en vivo (con milisegundos) */
const cb=['años','meses','días','horas','min','seg','milisegundos','días en total'];
$('#contador').innerHTML=cb.map((t,i)=>`<div><b id="c${i}">0</b><small>${t}</small></div>`).join('');
function contador(){const ini=new Date(C.desde+'T00:00:00'),h=new Date();
 if(h<ini){return}
 let m=(h.getFullYear()-ini.getFullYear())*12+h.getMonth()-ini.getMonth(),ref=new Date(ini);ref.setMonth(ref.getMonth()+m);
 if(ref>h){m--;ref=new Date(ini);ref.setMonth(ref.getMonth()+m)}
 const r=h-ref,us=String(h.getMilliseconds()).padStart(3,'0');
 [m/12|0,m%12,r/864e5|0,r/36e5%24|0,r/6e4%60|0,r/1e3%60|0,us,Math.floor((h-ini)/864e5)].forEach((v,k)=>{$('#c'+k).textContent=v})}
(function loop(){contador();requestAnimationFrame(loop)})();

/* timeline */
$('#hitos').innerHTML=C.hitos.map(h=>`<div class="hito"><small>${h.fecha}</small><h4>${h.titulo}</h4><p>${h.texto}</p></div>`).join('');
const obs=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('ve')),{threshold:.2});
document.querySelectorAll('.hito').forEach(e=>obs.observe(e));

/* galería con álbumes */
let lista=C.fotos.map((f,i)=>({...f,i}));
const albumes=['Todas',...new Set(C.fotos.map(f=>f.album).filter(Boolean))];
function pinta(){const g=$('#galeria');g.innerHTML='';
 lista.forEach((f,k)=>{const fig=document.createElement('figure');fig.className='polaroid';fig.tabIndex=0;
  fig.innerHTML=`<img loading="lazy" src="fotos/${f.archivo}" alt="${f.texto||''}"><figcaption>${f.texto||''}</figcaption>`;
  fig.querySelector('img').onerror=e=>{e.target.onerror=null;e.target.src=heart};
  fig.onclick=()=>abrir(k);fig.onkeydown=e=>e.key==='Enter'&&abrir(k);g.appendChild(fig)})}
$('#chips').hidden=albumes.length<2;
$('#chips').innerHTML=albumes.map((a,i)=>`<button class="${i?'':'on'}">${a}</button>`).join('');
$('#chips').onclick=e=>{if(e.target.tagName!=='BUTTON')return;
 document.querySelectorAll('#chips button').forEach(b=>b.classList.remove('on'));e.target.classList.add('on');
 const a=e.target.textContent;lista=C.fotos.map((f,i)=>({...f,i})).filter(f=>a==='Todas'||f.album===a);pinta()};
pinta();

/* cartas */
const F=C.cartaFinal;
$('#cartas').innerHTML=C.cartas.map(c=>`<div class="carta"><span class="s">💌</span>${c.titulo}<div class="t">${c.texto}</div></div>`).join('')+
 (F?`<div class="carta secreta"><span class="s">🔒</span>${F.titulo}<div class="cand"><input id="pw" type="password" placeholder="Escribe la contraseña" autocomplete="off"><button class="btn" id="pwb">Abrir 🔓</button><small id="pwh"></small></div><div class="t">${F.texto}</div></div>`:'');
$('#cartas').onclick=e=>{const c=e.target.closest('.carta');if(!c)return;
 if(c.classList.contains('secreta')){
  if(c.classList.contains('abierta')||e.target.id==='pw')return;
  if(e.target.id==='pwb'){const n=x=>x.toLowerCase().replace(/\s+/g,'');
   if(n($('#pw').value)===n(F.clave)||n($('#pw').value)==='teamo'){c.classList.remove('pide');c.classList.add('abierta');centro()}
   else{$('#pwh').textContent=F.pista||'Intenta otra vez 💗';c.classList.add('tiembla');setTimeout(()=>c.classList.remove('tiembla'),400)}
  }else{c.classList.add('pide');setTimeout(()=>$('#pw').focus(),50)}
  return}
 c.classList.toggle('abierta');burst(e.clientX,e.clientY,8)};
$('#cartas').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.id==='pw')$('#pwb').click()});

/* razones */
let ult=-1;$('#otra').onclick=e=>{let i;do{i=Math.random()*C.razones.length|0}while(i===ult&&C.razones.length>1);ult=i;
 $('#razon').textContent=C.razones[i];burst(e.clientX,e.clientY)};

/* listas con check */
function checklist(id,key,items,cont){let ok=lee(key,[]);const el=$(id);const cuenta=()=>{$(cont).textContent=`${ok.length} de ${items.length} cumplidas 💗`};
 el.innerHTML=items.map((p,i)=>`<li><label><input type="checkbox" data-i="${i}" ${ok.includes(i)?'checked':''}><span>${p}</span></label></li>`).join('');
 el.onchange=e=>{const i=+e.target.dataset.i;ok=ok.filter(x=>x!==i);if(e.target.checked){ok.push(i);const r=e.target.getBoundingClientRect();burst(r.x,r.y,10)}guarda(key,ok);cuenta()};cuenta()}
checklist('#planes','planes',C.planes,'#cPlanes');

/* pregunta final */
$('#preg').textContent=C.pregunta;
const no=$('#no');function huir(){no.style.transform=`translate(${(Math.random()-.5)*Math.min(260,innerWidth-120)}px,${(Math.random()-.5)*160}px)`}
no.onmouseenter=huir;no.ontouchstart=e=>{e.preventDefault();huir()};no.onclick=huir;
$('#si').onclick=()=>{$('#resp').style.display='none';$('#fin').textContent=C.final;centro();setTimeout(centro,500);setTimeout(centro,1000)};

/* entrada, música, mensaje */
function escribir(){const el=$('#mensaje');let i=0;const t=setInterval(()=>{el.textContent=C.mensaje.slice(0,++i);if(i>=C.mensaje.length){clearInterval(t);el.classList.add('fin')}},45)}
function entrar(){const e=$('#entrada');
 if(C.clave&&$('#clave').value.trim().toLowerCase()!==C.clave.toLowerCase()){e.classList.add('tiembla');setTimeout(()=>e.classList.remove('tiembla'),400);return}
 e.classList.add('abierta');escribir();for(let i=0;i<12;i++)setTimeout(corazon,i*90);
 if(C.musica){const a=$('#audio');a.src=C.musica;a.volume=.6;a.play().then(()=>$('#mus').classList.add('sonando')).catch(()=>{});$('#mus').hidden=false}}
$('#entrada').onclick=e=>{if(e.target.id!=='clave')entrar()};
$('#clave').onkeydown=e=>e.key==='Enter'&&entrar();
$('#entrada').onkeydown=e=>{if(e.target.id!=='clave'&&(e.key==='Enter'||e.key===' '))entrar()};
$('#mus').onclick=()=>{const a=$('#audio');a.paused?a.play():a.pause();$('#mus').classList.toggle('sonando',!a.paused)};

/* visor + presentación */
let act=0,tm=null;
function mostrar(){const f=lista[act],img=$('#vImg');img.onerror=()=>{img.onerror=null;img.src=heart};
 img.src='fotos/'+f.archivo;img.alt=f.texto||'';$('#vTxt').textContent=f.texto||'';$('#vCuenta').textContent=`${act+1} de ${lista.length}`}
function abrir(i){act=i;mostrar();$('#visor').classList.add('on')}
function cerrar(){$('#visor').classList.remove('on');clearInterval(tm);tm=null;$('#play').textContent='▶ Presentación'}
function mover(d){act=(act+d+lista.length)%lista.length;mostrar()}
$('#verTodas').onclick=()=>abrir(0);$('.cerrar').onclick=cerrar;$('.prev').onclick=()=>mover(-1);$('.next').onclick=()=>mover(1);
$('#play').onclick=()=>{if(tm){clearInterval(tm);tm=null;$('#play').textContent='▶ Presentación'}else{tm=setInterval(()=>mover(1),3000);$('#play').textContent='⏸ Pausar'}};
$('#visor').onclick=e=>{if(e.target.id==='visor')cerrar()};
document.addEventListener('keydown',e=>{if(!$('#visor').classList.contains('on'))return;
 if(e.key==='Escape')cerrar();if(e.key==='ArrowLeft')mover(-1);if(e.key==='ArrowRight')mover(1)});
let x0=null;$('#visor').addEventListener('touchstart',e=>x0=e.touches[0].clientX,{passive:true});
$('#visor').addEventListener('touchend',e=>{if(x0===null)return;const dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>50)mover(dx<0?1:-1);x0=null});

/* app instalable */
if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
